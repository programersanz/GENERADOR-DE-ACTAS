-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 22-11-2022 a las 16:42:44
-- Versión del servidor: 10.4.24-MariaDB
-- Versión de PHP: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `prueba`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `archivos`
--

CREATE TABLE `archivos` (
  `id` int(10) UNSIGNED NOT NULL,
  `acta` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `archivos`
--

INSERT INTO `archivos` (`id`, `acta`, `name`, `date`) VALUES
(1, 0, 'Rick Mrty.ico', '2022-11-16 11:32:40'),
(2, 0, 'acta_completa_master.rar', '2022-11-16 11:32:52'),
(3, 0, 'index.php', '2022-11-16 11:33:02'),
(4, 0, 'Hasta la proxima.wav', '2022-11-16 11:33:23'),
(5, 0, 'desktop.ini', '2022-11-16 11:33:29'),
(6, 0, 'Familia.jpg', '2022-11-16 11:47:17'),
(7, 0, 'desktop.ini', '2022-11-16 14:15:31'),
(8, 0, 'boarding_pass_preview.pdf', '2022-11-16 14:15:34'),
(25, 0, 'bootstrap-4.0.0-dist.zip', '2022-11-22 09:07:12'),
(26, 0, 'Rick Mrty.ico', '2022-11-22 09:15:42'),
(27, 0, 'Rick Mrty.ico', '2022-11-22 00:00:00'),
(28, 4, 'Rick Mrty.ico', '2022-11-25 00:00:00');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `archivos`
--
ALTER TABLE `archivos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `archivos`
--
ALTER TABLE `archivos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
