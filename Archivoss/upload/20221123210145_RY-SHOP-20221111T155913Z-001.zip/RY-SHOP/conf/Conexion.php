<?php
$server= "localhost";
$user= "root";
$pass= "";
$bd= "proyecto d.i.d.t";
$conexion = new mysqli($server, $user, $pass, $bd);
if (mysqli_connect_errno()) 
{
	echo "No conectado", mysqli_connect_errno();
	exit();
}else
{
  
}
?>