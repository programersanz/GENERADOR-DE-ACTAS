<?php
require_once 'config.php';
class Conectar{


public $_bd;

function __construct() {
        $this->_bd=new mysqli(server,user,pass,bd);
        

        if ($this->_bd->connect_errno){

            echo "fallo a conectar".$this->_bd->connect_errno;
            return;
        }
        $this->_bd->set_charset(DB_charse);
    }
}
?>