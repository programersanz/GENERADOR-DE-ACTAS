<?php
//definir las variables globales
define('server', 'localhost');
define('user','root');
define('pass','');
define('bd','proyecto d.i.d.t');
define('DB_charse','utf-8');
?>