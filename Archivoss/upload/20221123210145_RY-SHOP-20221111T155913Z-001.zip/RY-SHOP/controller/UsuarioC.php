<?php
require_once "../conf/Conexion.php";
require_once "../model/Usuario.php";
require_once "../view/RegistrarUsuario.php";



if (isset($_POST['enviar'])) {
	$iduser=$_POST['txtIdusuario'];
	$user=$_POST['txtNombreUsuario'];
	$cont=md5 ($_POST['txtcontraseña']);
	$car=$_POST['txtcargo'];



	$consul= new Usuario();
	$reg = $consul->RegistroUsuario($iduser, $user, $cont, $car);
	if ($reg) {
		print "<script> alert(\"usuario registrado\");
 		document.location='../view/RegistrarUsuario.php';</script>";
	}else{
		print "<script> alert(\"fallo al ingresar los datos\");
 		document.location='../view/RegistrarUsuario.php';</script>";
	}
}

?>