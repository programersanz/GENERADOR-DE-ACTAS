<?php
date_default_timezone_set("America/Lima");
// Iniciamos la clase de la carta
include '../model/modelCarta.php';
$cart = new carta;

// include database configuration file
include '../conf/Conexion.php';
if(isset($_REQUEST['action']) && !empty($_REQUEST['action'])){
    if($_REQUEST['action'] == 'addToCart' && !empty($_REQUEST['id'])){
        $productID = $_REQUEST['id'];
        // get product details
        $query = $conexion->query("SELECT * FROM producto WHERE id_producto = ".$productID);
        $row = $query->fetch_assoc();
        $itemData = array(
            'id' => $row['id_producto'],
            'name' => $row['NombreProducto'],
            'price' => $row['precio_producto'],
            'qty' => 1
        );
        
        $insertItem = $cart->insert($itemData);
        $redirectLoc = $insertItem?'../view/verCarta.php':'../view/interfazVendedor.php';
        header("Location: ".$redirectLoc);
    }elseif($_REQUEST['action'] == 'updateCartItem' && !empty($_REQUEST['id'])){
        $itemData = array(
            'rowid' => $_REQUEST['id'],
            'qty' => $_REQUEST['qty']
        );
        $updateItem = $cart->update($itemData);
        echo $updateItem?'ok':'err';die;
    }elseif($_REQUEST['action'] == 'removeCartItem' && !empty($_REQUEST['id'])){
        $deleteItem = $cart->remove($_REQUEST['id']);
        header("Location: ../view/verCarta.php");
    }elseif($_REQUEST['action'] == 'placeOrder' && $cart->total_itemss() > 0 || !empty($_SESSION['sessCustomerID'])){
        // insert order details into database
        $insertOrder = $conexion->query("INSERT INTO orden (precio_Total, fecha, hora) VALUES ('".$cart->total()."', '".date("Y-m-d H:i:s")."', '".date("Y-m-d H:i:s")."')");
        
        if($insertOrder){
            $orderID = $conexion->insert_id;
            $sql = '';
            // get cart items
            $cartItems = $cart->contents();
            foreach($cartItems as $item){
                $sql .= "INSERT INTO orden_articulos (orden_id, producto_id, cantidad) VALUES ('".$orderID."', '".$item['id']."', '".$item['qty']."');";
            }
            // insert order items into database
            $insertOrderItems = $conexion->multi_query($sql);
            
            if($insertOrderItems){
                $cart->destroy();
                header("Location:../view/OrdenExito.php?id=$orderID");
            }else{
                header("Location:../view/pagos.php");
            }
        }else{
            header("Location:../view/pagos.php");
        }
    }else{
        header("Location:../view/interfazVendedor.php");
    }
}else{
    header("Location:../view/interfazVendedor.php");
}