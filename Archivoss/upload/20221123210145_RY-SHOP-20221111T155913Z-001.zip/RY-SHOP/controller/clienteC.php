<?php
require_once "../conf/Conexion.php";
require_once "../model/cliente.php";
require_once "../view/RegistroCliente.php";



if (isset($_POST['enviar'])) {
	$idcliente=$_POST['txtIdcliente'];
	$nomcliente=$_POST['txtNombrecliente'];
	$apecliente=$_POST['txtapellido'];
	$telcliente=$_POST['txtTelefono'];



	$consul= new Cliente();
	$reg = $consul->registroCliente($idcliente, $nomcliente, $apecliente, $telcliente);
	if ($reg) {
		print "<script> alert(\"cliente registrado\");
 		document.location='../view/RegistroCliente.php';</script>";
	}else{
		print "<script> alert(\"fallo al ingresar los datos\");
 		document.location='../view/RegistroCliente.php';</script>";
	}
}

?>