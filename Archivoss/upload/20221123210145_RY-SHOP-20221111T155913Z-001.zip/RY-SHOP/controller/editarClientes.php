<?php
require_once "../conf/Conexion.php";
require_once "../model/cliente.php";
require_once "../view/RegistroCliente.php";


if (isset($_POST['actualizar'])) {
	$id= $_POST['txtIdcliente'];
	$nombre= $_POST['txtNombrecliente'];
	$apellido= $_POST['txtapellido'];
	$telefono= $_POST['txtTelefono'];




	$consul= new Cliente();
	$reg = $consul->ActualizarCliente($id,$nombre,$apellido,$telefono);


	if ($reg) {
		 print "<script>alert(\"Cliente actualizado\"); window.location='../view/RegistroCliente.php';</script>";
	}else{
		print "<script>alert(\"Cliente no actualizado\"); window.location='../view/RegistroCliente.php';</script>";
	}

}

?>