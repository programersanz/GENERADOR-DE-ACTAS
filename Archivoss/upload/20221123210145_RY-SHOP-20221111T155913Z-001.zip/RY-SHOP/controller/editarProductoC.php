<?php
require_once "../conf/Conexion.php";
require_once "../model/Producto.php";
require_once "../view/registroProducto.php";


if (isset($_POST['actualizarproducto'])) {
	$id= $_POST['txtProducto'];
	$nombre= $_POST['txtNombrepro'];
	$marca= $_POST['txtMarca'];
	$precio= $_POST['txtPrecio'];
	$cant= $_POST['txtCant'];
	$fecha= $_POST['txtFecha'];




	$consul= new Producto();
	$reg = $consul->ActualizarProducto($id,$nombre,$marca,$precio,$cant,$fecha);


	if ($reg) {
		 print "<script>alert(\"Producto actualizado\"); window.location='../view/registroProducto.php';</script>";
	}else{
		print "<script>alert(\"Producto no actualizado\"); window.location='../view/registroProducto.php';</script>";
	}

}

?>