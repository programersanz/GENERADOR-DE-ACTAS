<?php
require_once "../conf/Conexion.php";
require_once "../model/provedor.php";
require_once "../view/RegistrarProve.php";


if (isset($_POST['actualizarProve'])) {
	$id= $_POST['txtIDprovedor'];
	$nombre= $_POST['txtNombrepro'];
	$apellido= $_POST['txtApellidopro'];
	$telefono= $_POST['txtTelefono'];
	




	$consul= new Provedor();
	$reg = $consul->ActualizarProveedor($id,$nombre,$apellido,$telefono);


	if ($reg) {
		 print "<script>alert(\"proveedor actualizado\"); window.location='../view/RegistrarProve.php';</script>";
	}else{
		print "<script>alert(\"Proveedor no actualizado\"); window.location='../view/RegistrarProve.php';</script>";
	}

}

?>