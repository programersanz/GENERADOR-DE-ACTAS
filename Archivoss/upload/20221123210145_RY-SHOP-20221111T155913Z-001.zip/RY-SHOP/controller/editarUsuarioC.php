<?php
require_once "../conf/Conexion.php";
require_once "../model/Usuario.php";
require_once "../view/RegistrarUsuario.php";


if (isset($_POST['actualizar'])) {
	$id= $_POST['txtIdusuario'];
	$nombre= $_POST['txtNombreUsuario'];
	$pass= $_POST['txtcontraseña'];
	$car= $_POST['txtcargo'];




	$consul= new Usuario();
	$reg = $consul->ActualizarUsuario($id,$nombre,$pass,$car);


	if ($reg) {
		 print "<script>alert(\"Usuario actualizado\"); window.location='../view/RegistrarUsuario.php';</script>";
	}else{
		print "<script>alert(\"Usuario no actualizado\"); window.location='../view/RegistrarUsuario.php';</script>";
	}

}

?>