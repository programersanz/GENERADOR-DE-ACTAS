<?php
require_once "../conf/Conexion.PHP";

if (isset($_GET['id'])) {
	$id=$_GET['id'];
	$query="DELETE FROM producto WHERE id_producto='$id'";


	if ($conexion->query($query)) {
		print "<script>alert(\"Registro eliminado \"); window.location='../view/registroProducto.php';</script>";
	}else{
		echo "Error no se pudo eliminar el registro";
	}
}else{
	echo "No se pudo procesar la petición";
}
?>