<?php
require_once "../conf/Conexion.PHP";

if (isset($_GET['id'])) {
	$id=$_GET['id'];
	$query="DELETE FROM proveedor WHERE id_proveedor='$id'";


	if ($conexion->query($query)) {
		print "<script>alert(\"Registro eliminado \"); window.location='../view/RegistrarProve.php';</script>";
	}else{
		echo "Error no se pudo eliminar el registro";
	}
}else{
	echo "No se pudo procesar la petición";
}
?>