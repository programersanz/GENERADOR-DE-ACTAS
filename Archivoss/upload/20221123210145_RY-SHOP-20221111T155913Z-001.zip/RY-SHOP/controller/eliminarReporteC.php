<?php
require_once "../conf/Conexion.PHP";

if (isset($_GET['id'])) {
	$id=$_GET['id'];
	$query="DELETE FROM informe_administrativo WHERE id_informe='$id'";


	if ($conexion->query($query)) {
		print "<script>alert(\"Registro eliminado \"); window.location='../view/Radmin.php';</script>";
	}else{
		echo "Error no se pudo eliminar el registro";
	}
}else{
	echo "No se pudo procesar la petición";
}
?>