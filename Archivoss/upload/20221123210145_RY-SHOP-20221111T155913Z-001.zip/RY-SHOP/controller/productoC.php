<?php
require_once "../conf/Conexion.php";
require_once "../model/Producto.php";
require_once "../view/registroProducto.php";



if (isset($_POST['enviar'])) {
	$idproduc= $_POST['txtProducto'];
	$nomproduc= $_POST['txtNombrepro'];
	$promarca= $_POST['txtMarca'];
	$prepro= $_POST['txtPrecio'];
	$cantProduct= $_POST['txtCant'];
	$fechapro= $_POST['txtFecha'];


$consul= new Producto();
$reg= $consul->RegistroProducto($idproduc, $nomproduc, $promarca, $prepro, $cantProduct, $fechapro);

if ($reg) {
	print "<script> alert (\"Producto registrado\"); window.location='../view/registroProducto.php'; </script>";
}else{
	print "<script> alert (\"Fallo al ingresar los datos\"); window.location='../view/registroProducto.php'; </script>";
}
}


?>