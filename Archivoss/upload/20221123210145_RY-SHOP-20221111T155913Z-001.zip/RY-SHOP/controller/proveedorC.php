<?php
require_once "../conf/Conexion.php";
require_once "../model/provedor.php";
require_once "../view/RegistrarProve.php";



if (isset($_POST['enviar'])) {
	$idproveedor=$_POST['txtIDprovedor'];
	$nomproveedor=$_POST['txtNombrepro'];
	$apeproveedor=$_POST['txtApellidopro'];
	$telproveedor=$_POST['txtTelefono'];



	$consul= new Provedor();
	$reg = $consul-> registroProvedor($idproveedor, $nomproveedor, $apeproveedor, $telproveedor);
	if ($reg) {
		print "<script> alert(\"proveedor registrado\");
 		document.location='../view/RegistrarProve.php';</script>";
	}else{
		print "<script> alert(\"fallo al ingresar los datos\");
 		document.location='../view/RegistrarProve.php';</script>";
	}
}

?>