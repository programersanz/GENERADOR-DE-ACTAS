<?php
require_once "../conf/Conexion.php";
require_once "../model/reporteAdmin.php";
require_once "../view/Radmin.php";



if (isset($_POST['enviar'])) {
	$id=$_POST['txtIdreporte'];
	$fecha=$_POST['txtfechai'];
	$hora=$_POST['txthora'];
	$nombre=$_POST['txtnombre'];
	$ordenp=$_POST['txtordenP'];
	$ordena=$_POST['txtordenA'];
	



	$consul= new Reporte();
	$reg = $consul->RegistroReporteAd($id, $fecha, $hora, $nombre, $ordenp, $ordena);
	if ($reg) {
		print "<script> alert(\"reporte registrado\");
 		document.location='../view/Radmin.php';</script>";
	}else{
		print "<script> alert(\"fallo al ingresar los datos\");
 		document.location='../view/Radmin.php';</script>";
	}
}

?>