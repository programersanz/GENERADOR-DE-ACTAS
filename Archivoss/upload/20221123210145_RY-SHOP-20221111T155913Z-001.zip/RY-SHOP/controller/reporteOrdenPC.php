<?php
require_once "../conf/Conexion.php";
require_once "../model/reporteOrdenpedido.php";
require_once "../view/RordenPedido.php";



if (isset($_POST['enviar'])) {
	$id=$_POST['txtIdorden'];
	$fecha=$_POST['txtfechaP'];
	$hora=$_POST['txthoraP'];
	$proveedor=$_POST['txtProveedor'];
    $nombreB=$_POST['txtnombre'];
    $obser=$_POST['txtOb'];



	$consul= new OrdenP();
	$reg = $consul->RegistroReporteOd($id, $fecha, $hora, $proveedor, $nombreB, $obser);
	if ($reg) {
		print "<script> alert(\"reporte registrado\");
 		document.location='../view/RordenPedido.php';</script>";
	}else{
		print "<script> alert(\"fallo al ingresar los datos\");
 		document.location='../view/RordenPedido.php';</script>";
	}
}

?>