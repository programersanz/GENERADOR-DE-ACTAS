<!DOCTYPE html>
<!--code by codingflicks.com-->
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ROYALE SYSTEMS</title>
    <link rel="stylesheet" href="css/principal.css">
</head>
<body>
<div class=homepage>
  <img src="img/LOGO.png" style="width:10%; height:10%;">
  <h2>RY-SHOP</h2>
   <p>Nuestro sistema sistematizara y mejorara tus procesos de ventas, administrativos y de inventario.</p>
</div>
    

    <div class="boxes">
        <ul class="single-box">
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
        </ul>
    </div>
    <button class="boton">
      <a href="php/inicioDeSesion.php">Iniciar sesión</a>
    </button>
</body>
</html>