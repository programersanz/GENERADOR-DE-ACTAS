<?php
require_once '../conf/conexionpoo.php';

class Producto extends Conectar{

protected $idproducto;
protected $nomproducto;
protected $marca;
protected $preproducto;
protected $canti;
protected $fecha;

public function RegistroProducto($idproducto, $nomproducto, $marca, $preproducto, $canti, $fecha)
{
$sql="SELECT * FROM producto WHERE id_producto='$idproducto'";
$resultado= $this->_bd->query($sql);
$fila= mysqli_num_rows($resultado);

if ($fila >0 ) {
	echo "<script> alert ('El producto ya esta registrado'); window.location='../view/registroProducto.php'; </script>";
}else{
	$sql1= "INSERT INTO producto (id_producto, NombreProducto, Marca, precio_producto, cantidad, fecha_caducidad) VALUES ('".$idproducto."', '".$nomproducto."', '".$marca."', '".$preproducto."','".$canti."', '".$fecha."')";
	$resul= $this->_bd->query($sql1);
if (!$resul) {
	print "<script> alert (\"Fallo al ingresar los datos\"); window.location='../view/registroProducto.php'; </script>";
}else{
	return $resul;
	print "<script> alert (\"Datos ingresados correctamente\"); window.location='../view/registroProducto.php'; </script>";
	$resul->close();
	$this->db->close();
}
}
}

public function ListarProductos()
{
$sql= "SELECT * FROM producto ORDER BY id_producto";
$Result= $this->_bd-> query($sql);
if ($Result->num_rows>0) 
{
	while ($row= $Result->fetch_assoc()) {
		$resultset[]=$row;
	}
}
return $resultset;
}
public function BuscarProducto($palabra){
	$sql2="SELECT * FROM producto WHERE id_producto LIKE '%$palabra%'";
	$buscar =$this->_bd->query($sql2);
	if ($buscar->num_rows>0) {
		while ($row = $buscar->fetch_assoc()) {
			$resultset[]= $row;
		}
	}
	return $resultset;
}



public function ActualizarProducto($id,$nombre,$marca,$precio,$cantid,$fechacaducidad){

$query= "UPDATE producto SET id_producto='$id', NombreProducto='$nombre', Marca='$marca', precio_producto='$precio', cantidad='$cantid', fecha_caducidad='$fechacaducidad' WHERE id_producto=$id";
$Resul= $this->_bd->query($query);
if (!$Resul) {
 print "<script>alert(\"Fallo al actualizar los datos\"); window.location='../registroProducto.php';</script>";
}else{
	return $Resul;
	 print "<script>alert(\"Los datos del cliente han sido actualizados\"); window.location='../registroProducto.php';</script>";
	 $Resul->close();
	 $this->db->close();
}
}

public function EliminarProducto(){

	$query="DELETE FROM producto WHERE id_producto='$id'";
	$Resul2= $this->bd->query($query);
if(!$Resul2){
    print "<script>alert(\"Registro eliminado\"); window.location='../registroProducto.php';</script>";
}else{
    print "<script>alert(\"Fallo al eliminar los datos\"); window.location='../registroProducto.php';</script>";
}

}


}


?>