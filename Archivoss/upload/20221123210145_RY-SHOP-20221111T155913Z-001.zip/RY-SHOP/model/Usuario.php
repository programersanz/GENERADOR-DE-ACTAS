<?php 
    require_once '../conf/conexionpoo.php';
    class Usuario extends Conectar{

        protected $idusuario;
        protected $user;
        protected $password;
        protected $cargo_idd;


public function RegistroUsuario($idusuario, $user, $password, $cargo_idd)
{
$sql="SELECT * FROM usuarios WHERE IdUsuarios='$idusuario'";
$resultado= $this->_bd->query($sql);
$fila= mysqli_num_rows($resultado);

if ($fila >0 ) {
	echo "<script> alert ('El usuario ya esta registrado'); window.location='../view/RegistrarUsuario.php'; </script>";
}else{
	$sql1= "INSERT INTO usuarios (IdUsuarios, username, clavelo, cargo_id) VALUES ('".$idusuario."', '".$user."', '".$password."', '".$cargo_idd."')";
	$resul= $this->_bd->query($sql1);
if (!$resul) {
	print "<script> alert (\"Fallo al ingresar los datos\"); window.location='../view/RegistrarUsuario.php'; </script>";
}else{
	return $resul;
	print "<script> alert (\"Datos ingresados correctamente\"); window.location='../view/RegistrarUsuario.php'; </script>";
	$resul->close();
	$this->db->close();
}
}
}
        
        public function ListarUsuario()
        {
        $sql= "SELECT * FROM usuarios ORDER BY IdUsuarios";
        $Result= $this->_bd-> query($sql);
        if ($Result->num_rows>0) 
        {
            while ($row= $Result->fetch_assoc()) {
                $resultset[]=$row;
            }
        }
        return $resultset;
        }

        public function ActualizarUsuario($id, $userm, $pass, $cargod){

            $query= "UPDATE usuarios SET IdUsuarios='$id', username='$userm', clavelo='$pass', cargo_id='$cargod' WHERE IdUsuarios=$id";
            $Resul= $this->_bd->query($query);
            if (!$Resul) {
             print "<script>alert(\"Fallo al actualizar los datos\"); window.location='../view/RegistrarUsuario.php';</script>";
            }else{
                return $Resul;
                 print "<script>alert(\"Los datos del cliente han sido actualizados\"); window.location='../view/RegistrarUsuario.php';</script>";
                 $Resul->close();
                 $this->db->close();
            }
            }
            public function EliminarCliente(){

                $query="DELETE FROM usuarios WHERE IdUsuarios='$id'";
                $Resul2= $this->bd->query($query);
            if(!$Resul2){
                print "<script>alert(\"Registro eliminado\"); window.location='../RegistrarUsuario.php';</script>";
            }else{
                print "<script>alert(\"Fallo al eliminar los datos\"); window.location='../RegistrarUsuario.php';</script>";
            }
            
            }
        
        }

?>