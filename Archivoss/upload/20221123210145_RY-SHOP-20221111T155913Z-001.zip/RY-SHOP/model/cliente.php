<?php
require_once '../conf/conexionpoo.php';




class Cliente extends Conectar{

protected $idcliente;
protected $nombrecliente; 
protected $apellidocliente; 
protected $telefonocliente;

/*registro clientes */
public function RegistroCliente($idcliente, $nombrecliente, $apellidocliente, $telefonocliente)
{
$sql="SELECT *FROM clientes WHERE id_cliente='$idcliente'";
$resultado= $this->_bd->query($sql);
$fila= mysqli_num_rows($resultado);



if ($fila > 0) {
	echo "<script> alert ('El cliente ya esta registrado');
	window.location='../view/RegistroCliente.php'; </script>";
}else{

	$sql1 = "INSERT INTO clientes (id_cliente, NombreCliente, ApellidoCliente, telefonoCliente) VALUES ('".$idcliente."', '".$nombrecliente."', '".$apellidocliente."', '".$telefonocliente."')";
	$resul= $this->_bd->query($sql1);
if (!$resul) {
	print "<script> alert (\"Fallo al ingresar los datos\"); window.location= '../view/RegistroCliente.php'; </script>";
}else{
	return $resul;
	print "<script> alert (\"Datos ingresados correctamente\"); window.location= '../view/RegistroCliente.php'; </script>";



	$resul->close();
	$this->db->close();
}
}
}
/*listar clientes */
public function ListarClientes()
{
$sql= "SELECT * FROM clientes ORDER BY id_cliente";
$Result= $this->_bd-> query($sql);
if ($Result->num_rows>0) 
{
	while ($row= $Result->fetch_assoc()) {
		$resultset[]=$row;
	}
}
return $resultset;
}
/* buscar clientes */
public function BuscarCliente($palabra){
	$sql2="SELECT * FROM clientes WHERE id_cliente LIKE '%$palabra%'";
	$buscar =$this->_bd->query($sql2);
	if ($buscar->num_rows>0) {
		while ($row = $buscar->fetch_assoc()) {
			$resultset[]= $row;
		}
	}
	return $resultset;
}

/*actualizar clientes */
public function ActualizarCliente($id,$nombre,$apellido,$telefono){

$query= "UPDATE clientes SET id_cliente='$id', NombreCliente='$nombre', ApellidoCliente='$apellido', telefonoCliente='$telefono' WHERE id_cliente=$id";
$Resul= $this->_bd->query($query);
if (!$Resul) {
 print "<script>alert(\"Fallo al actualizar los datos\"); window.location='../view/RegistroCliente.php';</script>";
}else{
	return $Resul;
	 print "<script>alert(\"Los datos del cliente han sido actualizados\"); window.location='../view/RegistroCliente.php';</script>";
	 $Resul->close();
	 $this->db->close();
}
}
/* eliminar clientes */
public function EliminarCliente(){

	$query="DELETE FROM clientes WHERE id_cliente='$id'";
	$Resul2= $this->bd->query($query);
if(!$Resul2){
    print "<script>alert(\"Registro eliminado\"); window.location='../RegistroCliente.php';</script>";
}else{
    print "<script>alert(\"Fallo al eliminar los datos\"); window.location='../RegistroCliente.php';</script>";
}

}



}
?>