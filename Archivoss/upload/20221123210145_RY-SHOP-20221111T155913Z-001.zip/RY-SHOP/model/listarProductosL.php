<?php 
require_once '../conf/conexionpoo.php';
class ProductoL extends Conectar{
    protected $idproducto;
    protected $nomproducto;
    protected $marca;
    protected $preproducto;
    protected $canti;
    protected $fecha;

    public function ListarProductos()
    {
    $sql= "SELECT * FROM producto ORDER BY id_producto";
    $Result= $this->_bd-> query($sql);
    if ($Result->num_rows>0) 
    {
        while ($row= $Result->fetch_assoc()) {
            $resultset[]=$row;
        }
    }
    return $resultset;
    }

    public function BuscarProducto($palabra){
        $sql2="SELECT * FROM producto WHERE id_producto LIKE '%$palabra%'";
        $buscar =$this->_bd->query($sql2);
        if ($buscar->num_rows>0) {
            while ($row = $buscar->fetch_assoc()) {
                $resultset[]= $row;
            }
        }
        return $resultset;
    }




}



?>