<?php

require_once '../conf/conexionpoo.php';



class Provedor extends Conectar{


protected $IdProveedor;
protected $NombreProveedor;
protected $ApellidoProveedor;
protected $TelefonoProveedor;


public function _construct(){
	parent::_construct();
}

public function registroProvedor ($IdProveedor, $NombreProveedor, $ApellidoProveedor, $TelefonoProveedor){
	$sql1= "SELECT * FROM proveedor WHERE id_proveedor= '$IdProveedor' ";
	$resultado= $this->_bd->query($sql1);
	$fila= mysqli_num_rows($resultado);

if ($fila > 0) {
	echo "<script> alert('Proveedor ya esta registrado');
   	  document.location ='../view/RegistrarProve.php'; </script>";
}else{
	$sql = "INSERT INTO proveedor (id_proveedor, nombre_proveedor, apellido_proveedor, telefono_proveedor) VALUES ('".$IdProveedor."', '".$NombreProveedor."', '".$ApellidoProveedor."', ".$TelefonoProveedor.")";
	$resul= $this->_bd->query($sql);
if (!$resul) {
	print "<script> alert(\"Fallo al ingresar los datos.\"); window.location='../view/RegistrarProve.php';</script>";
}else{

	return $resul;
	print "<script> alert(\"Datos ingresados correctamente.\"); window.location='../view/RegistrarProve.php';</script>";


	$resul->close();
	$this->db->close();
}
}
}
public function ListarProveedor()
{
$sql= "SELECT * FROM proveedor ORDER BY id_proveedor";
$Result= $this->_bd-> query($sql);
if ($Result->num_rows>0) 
{
	while ($row= $Result->fetch_assoc()) {
		$resultset[]=$row;
	}
}
return $resultset;
}
public function BuscarProveedor($palabra){
	$sql2="SELECT * FROM proveedor WHERE id_proveedor LIKE '%$palabra%'";
	$buscar =$this->_bd->query($sql2);
	if ($buscar->num_rows>0) {
		while ($row = $buscar->fetch_assoc()) {
			$resultset[]= $row;
		}
	}
	return $resultset;
}


public function ActualizarProveedor($id,$nombre,$apellido,$telefono){

$query= "UPDATE proveedor SET id_proveedor='$id', nombre_proveedor='$nombre', apellido_proveedor='$apellido', telefono_proveedor='$telefono' WHERE id_proveedor=$id";
$Resul= $this->_bd->query($query);
if (!$Resul) {
 print "<script>alert(\"Fallo al actualizar los datos\"); window.location='../RegistrarProve.php';</script>";
}else{
	return $Resul;
	 print "<script>alert(\"Los datos del cliente han sido actualizados\"); window.location='../RegistrarProve.php';</script>";
	 $Resul->close();
	 $this->db->close();
}
}
public function EliminarProveedor(){

	$query="DELETE FROM proveedor WHERE id_proveedor='$id'";
	$Resul2= $this->bd->query($query);
if(!$Resul2){
    print "<script>alert(\"Registro eliminado\"); window.location='../RegistrarProve.php';</script>";
}else{
    print "<script>alert(\"Fallo al eliminar los datos\"); window.location='../RegistrarProve.php';</script>";
}

}

}

?>