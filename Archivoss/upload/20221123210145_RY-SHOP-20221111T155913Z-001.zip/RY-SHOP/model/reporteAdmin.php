<?php 
    require_once '../conf/conexionpoo.php';
    class Reporte extends Conectar{

        protected $idinforme;
        protected $fecha;
        protected $hora;
        protected $admin;
        protected $informeP;
        protected $informeA;


public function RegistroReporteAd($idinforme, $fecha, $hora, $admin, $informeP, $informeA)
{
$sql="SELECT * FROM informe_administrativo WHERE id_informe='$idinforme'";
$resultado= $this->_bd->query($sql);
$fila= mysqli_num_rows($resultado);

if ($fila >0 ) {
	echo "<script> alert ('El informe ya esta registrado'); window.location='../view/Radmin.php'; </script>";
}else{
	$sql1= "INSERT INTO informe_administrativo (id_informe, fecha_informe, hora_informe, Nombre_admin, ordenP_informe, ordenA_informe) VALUES ('".$idinforme."', '".$fecha."', '".$hora."', '".$admin."','".$informeP."','".$informeA."')";
	$resul= $this->_bd->query($sql1);
if (!$resul) {
	print "<script> alert (\"Fallo al ingresar los datos\"); window.location='../view/Radmin.php'; </script>";
}else{
	return $resul;
	print "<script> alert (\"Datos ingresados correctamente\"); window.location='../view/Radmin.php'; </script>";
	$resul->close();
	$this->db->close();
}
}
}
        
        public function ListarReporte()
        {
        $sql= "SELECT * FROM informe_administrativo ORDER BY id_informe ";
        $Result= $this->_bd-> query($sql);
        if ($Result->num_rows>0) 
        {
            while ($row= $Result->fetch_assoc()) {
                $resultset[]=$row;
            }
        }
        return $resultset;
        }


        public function EliminarReporte(){

            $query="DELETE FROM informe_administrativo WHERE id_informe='$id'";
            $Resul2= $this->bd->query($query);
        if(!$Resul2){
            print "<script>alert(\"Registro eliminado\"); window.location='../view/Radmin.php';</script>";
        }else{
            print "<script>alert(\"Fallo al eliminar los datos\"); window.location='../view/Radmin.php';</script>";
        }
        
        }

        }

?>