<?php 
    require_once '../conf/conexionpoo.php';
    class OrdenP extends Conectar{

        protected $idordenP;
        protected $fechaP;
        protected $horaP;
        protected $ProveedorP;
        protected $nombre;
        protected $Obser;

public function RegistroReporteOd($idordenP, $fechaP, $horaP, $proveedorP, $nombre, $Obser)
{
$sql="SELECT * FROM orden_pedido WHERE id_orden='$idordenP'";
$resultado= $this->_bd->query($sql);
$fila= mysqli_num_rows($resultado);

if ($fila >0 ) {
	echo "<script> alert ('La orden ya esta registrado'); window.location='../view/RordenPedido.php'; </script>";
}else{
	$sql1= "INSERT INTO orden_pedido (id_orden, fecha_orden, hora_orden, Proveedor_orden, Nombre_bodeguero, Observaciones) VALUES ('".$idordenP."', '".$fechaP."', '".$horaP."', '".$proveedorP."', '".$nombre."', '".$Obser."')";
	$resul= $this->_bd->query($sql1);
if (!$resul) {
	print "<script> alert (\"Fallo al ingresar los datos\"); window.location='../view/RordenPedido.php'; </script>";
}else{
	return $resul;
	print "<script> alert (\"Datos ingresados correctamente\"); window.location='../view/RordenPedido.php'; </script>";
	$resul->close();
	$this->db->close();
}
}
}
        
        public function ListarOrdenP()
        {
        $sql= "SELECT * FROM orden_pedido ORDER BY id_orden ";
        $Result= $this->_bd-> query($sql);
        if ($Result->num_rows>0) 
        {
            while ($row= $Result->fetch_assoc()) {
                $resultset[]=$row;
            }
        }
        return $resultset;
        }


        public function EliminarReporte(){

            $query="DELETE FROM orden_pedido WHERE id_orden='$id'";
            $Resul2= $this->bd->query($query);
        if(!$Resul2){
            print "<script>alert(\"Registro eliminado\"); window.location='../view/RordenPedido.php';</script>";
        }else{
            print "<script>alert(\"Fallo al eliminar los datos\"); window.location='../view/RordenPedido.php';</script>";
        }
        
        }

        }

?>