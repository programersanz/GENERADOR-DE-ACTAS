<?php 
require_once '../conf/conexionpoo.php';

class Venta extends Conectar{

protected $idorden;
protected $precioT;
protected $fecha;
protected $hora;

public function ListarVenta()
{
$sql= "SELECT * FROM orden ORDER BY id_ordenV";
$Result= $this->_bd-> query($sql);
if ($Result->num_rows>0) 
{
	while ($row= $Result->fetch_assoc()) {
		$resultset[]=$row;
	}
}
return $resultset;
}
public function BuscarVenta($palabra){
	$sql2="SELECT * FROM orden WHERE id_ordenV LIKE '%$palabra%'";
	$buscar =$this->_bd->query($sql2);
	if ($buscar->num_rows>0) {
		while ($row = $buscar->fetch_assoc()) {
			$resultset[]= $row;
		}
	}
	return $resultset;
}
}


?>