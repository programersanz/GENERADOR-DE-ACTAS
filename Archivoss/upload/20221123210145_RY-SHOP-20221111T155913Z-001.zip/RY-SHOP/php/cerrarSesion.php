<?php
session_start();
session_destroy();
print "<script>alert(\"La sesion se ha cerrado\");
window.location='../index.php';</script>";
?>