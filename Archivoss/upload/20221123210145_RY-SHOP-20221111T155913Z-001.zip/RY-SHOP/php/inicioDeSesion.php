
<?php
 session_start();
 if (isset($_SESSION ['username'])) {
	if ($_SESSION['username']['cargo_id']=="1") {
		header("Location: ../view/iinterfazadmin.php");
	}else if($_SESSION['username']['cargo_id']=="2"){
		header("Location: ../view/iterfazVendedor.php");
	}else if ($_SESSION['username']['cargo_id']=="3") {
		header("Location: ../view/interfazBodeguero.php");
	}
 }
?>
<!DOCTYPE html>
<html lang="es">

<head>
	<meta charset="utf-8">
	<title>iniciar sesion</title>
<link rel="stylesheet" type="text/css" href="../css/inicioSesion.css">
<script src="https://kit.fontawesome.com/6878bca7b7.js" crossorigin="anonymous"></script>
</head>
<body>
	<div class="imagen">
	</div>

	<form class="formulario" action="login.php" method="POST">
	<img src="../img/h1.png">
		<h1>Iniciar Sesión</h1>
		<div class="input-container">
			<input type="text" name="txtNombreusu" placeholder="Nombre usuario">
		</div>

		<div class="input-container">
			<input type="password" name="txtContra" placeholder="Contraseña">
		</div>
		<button type="submit" name="enviar" class="button">Iniciar sesión</button>
	
</form>

</body>
</html>
