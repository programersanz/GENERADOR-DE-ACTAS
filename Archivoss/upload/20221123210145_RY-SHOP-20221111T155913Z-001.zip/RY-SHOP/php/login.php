<?php
include ("../conf/Conexion.php");
include ("../conf/config.php");

session_start();
$usuario1= $_POST['txtNombreusu'];
$clave=md5($_POST['txtContra']);
$query= "SELECT * FROM usuarios WHERE username='$usuario1' AND clavelo='$clave'";
$consulta2=$conexion->query($query);
if ($consulta2->num_rows>=1){
	$fila=$consulta2->fetch_array(MYSQLI_ASSOC);

	$_SESSION['username']=$fila;
	$_SESSION['user']=$fila['username'];
	$_SESSION['verificar']=true;

if ($_SESSION['username']['cargo_id']=="1") {
	header("Location: ../view/iinterfazadmin.php");
}elseif ($_SESSION['username']['cargo_id']=="2") {
	header("Location: ../view/interfazVendedor.php");
}elseif ($_SESSION['username']['cargo_id']=="3") {
	header("Location: ../view/interfazBodeguero.php");
}

}
else{
	print "<script>alert(\"Datos no correctos.\");
	window.location='inicioDeSesion.php';</script>";
}
?>