-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 30-05-2022 a las 20:06:16
-- Versión del servidor: 10.4.24-MariaDB
-- Versión de PHP: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `proyecto d.i.d.t`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cargo`
--

CREATE TABLE `cargo` (
  `cargo_id` int(11) NOT NULL,
  `NombreCargo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `cargo`
--

INSERT INTO `cargo` (`cargo_id`, `NombreCargo`) VALUES
(1, 'Administrador'),
(2, 'vendedor'),
(3, 'bodeguero');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `id_cliente` int(11) NOT NULL,
  `NombreCliente` varchar(100) NOT NULL,
  `ApellidoCliente` varchar(100) NOT NULL,
  `telefonoCliente` varchar(100) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`id_cliente`, `NombreCliente`, `ApellidoCliente`, `telefonoCliente`, `status`) VALUES
(1, 'Hector', 'Castillos', '3203334107', '1'),
(2, 'Lionel andres', 'Messi', '54545465', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `informe_administrativo`
--

CREATE TABLE `informe_administrativo` (
  `id_informe` int(11) NOT NULL,
  `fecha_informe` date NOT NULL,
  `hora_informe` time NOT NULL,
  `Nombre_admin` text NOT NULL,
  `ordenP_informe` int(11) NOT NULL,
  `ordenA_informe` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `informe_administrativo`
--

INSERT INTO `informe_administrativo` (`id_informe`, `fecha_informe`, `hora_informe`, `Nombre_admin`, `ordenP_informe`, `ordenA_informe`) VALUES
(1, '2022-04-05', '19:26:00', 'David Galindo', 1, 1),
(2, '2022-04-05', '19:26:00', 'Duban Castillo', 1, 1),
(3, '2022-05-04', '18:39:00', 'Ingrid Ayala', 3, 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `orden`
--

CREATE TABLE `orden` (
  `id_ordenV` int(11) NOT NULL,
  `precio_Total` float(10,2) NOT NULL,
  `fecha` datetime NOT NULL,
  `hora` datetime NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `orden`
--

INSERT INTO `orden` (`id_ordenV`, `precio_Total`, `fecha`, `hora`, `status`) VALUES
(24, 12000.00, '2022-04-05 18:55:53', '2022-04-05 18:55:53', '1'),
(25, 4500.00, '2022-04-05 19:21:48', '2022-04-05 19:21:48', '1'),
(26, 20500.00, '2022-04-05 19:27:51', '2022-04-05 19:27:51', '1'),
(27, 4500.00, '2022-05-03 22:06:34', '2022-05-03 22:06:34', '1'),
(28, 12000.00, '2022-05-03 22:09:54', '2022-05-03 22:09:54', '1'),
(29, 25500.00, '2022-05-04 21:20:20', '2022-05-04 21:20:20', '1'),
(30, 8500.00, '2022-05-19 18:24:02', '2022-05-19 18:24:02', '1'),
(31, 17000.00, '2022-05-20 17:59:19', '2022-05-20 17:59:19', '1'),
(32, 17000.00, '2022-05-27 20:48:23', '2022-05-27 20:48:23', '1'),
(33, 17000.00, '2022-05-28 19:46:04', '2022-05-28 19:46:04', '1'),
(34, 23500.00, '2022-05-30 13:03:48', '2022-05-30 13:03:48', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `orden_articulos`
--

CREATE TABLE `orden_articulos` (
  `id_articulo` int(11) NOT NULL,
  `orden_id` int(11) NOT NULL,
  `producto_id` int(11) NOT NULL,
  `cantidad` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `orden_articulos`
--

INSERT INTO `orden_articulos` (`id_articulo`, `orden_id`, `producto_id`, `cantidad`) VALUES
(1, 24, 3, 1),
(2, 25, 2, 1),
(3, 26, 3, 1),
(4, 26, 1, 1),
(5, 27, 2, 1),
(6, 28, 3, 1),
(7, 29, 1, 1),
(8, 29, 2, 2),
(9, 30, 2, 1),
(10, 31, 1, 1),
(11, 31, 2, 1),
(12, 32, 1, 1),
(13, 32, 2, 1),
(14, 33, 1, 1),
(15, 33, 2, 1),
(16, 34, 1, 1),
(17, 34, 3, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `orden_pedido`
--

CREATE TABLE `orden_pedido` (
  `id_orden` int(11) NOT NULL,
  `fecha_orden` date NOT NULL,
  `hora_orden` time NOT NULL,
  `Proveedor_orden` int(11) NOT NULL,
  `Nombre_bodeguero` text NOT NULL,
  `Observaciones` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `orden_pedido`
--

INSERT INTO `orden_pedido` (`id_orden`, `fecha_orden`, `hora_orden`, `Proveedor_orden`, `Nombre_bodeguero`, `Observaciones`) VALUES
(1, '2022-04-05', '19:15:00', 1, 'rosalia', '5 cremas 10 labiales, 20 pestañinas, 15 cremas cara'),
(2, '2022-04-05', '19:22:00', 1, 'David Galindo', '5 cremas 10 labiales, 20 pestañinas, 15 cremas cara'),
(3, '2022-05-03', '22:54:00', 1, 'Hernesto', '6 labiales');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `id_producto` int(11) NOT NULL,
  `NombreProducto` varchar(100) NOT NULL,
  `Marca` varchar(100) NOT NULL,
  `precio_producto` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `fecha_caducidad` date NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`id_producto`, `NombreProducto`, `Marca`, `precio_producto`, `cantidad`, `fecha_caducidad`, `status`) VALUES
(1, 'Esmaltes', 'Masglow', 8500, 45, '2025-07-10', '1'),
(2, 'Tintes ', 'DuvyClass', 12000, 28, '2022-08-27', '1'),
(3, 'Pestañina', 'Bogue', 15000, 85, '2022-12-23', '1'),
(4, 'Labial ', 'Esika', 15000, 32, '2022-07-15', '1'),
(5, 'Brillo ', 'Esika', 8000, 14, '2022-10-27', '1'),
(6, 'Delineador', 'Avon ', 14000, 65, '2022-11-25', '1'),
(7, 'Sombras', 'Cy-Zone', 24000, 12, '2022-08-14', '1'),
(8, 'Rubor', 'Avon', 12000, 20, '2022-05-19', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedor`
--

CREATE TABLE `proveedor` (
  `id_proveedor` int(11) NOT NULL,
  `nombre_proveedor` varchar(11) NOT NULL,
  `apellido_proveedor` varchar(11) NOT NULL,
  `telefono_proveedor` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `proveedor`
--

INSERT INTO `proveedor` (`id_proveedor`, `nombre_proveedor`, `apellido_proveedor`, `telefono_proveedor`) VALUES
(1, 'Duban', 'Castillo ', '32033341078'),
(2, 'cristiano ', 'ronaldo naz', '46456465465');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `IdUsuarios` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `clavelo` varchar(100) NOT NULL,
  `cargo_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`IdUsuarios`, `username`, `clavelo`, `cargo_id`) VALUES
(1, 'duban55', '25f9e794323b453885f5181f1b624d0b', 1),
(2, 'user12', '81dc9bdb52d04dc20036dbd8313ed055', 2),
(4, 'steven55', 'e10adc3949ba59abbe56e057f20f883e', 1),
(5, 'castillo11', 'e10adc3949ba59abbe56e057f20f883e', 3);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cargo`
--
ALTER TABLE `cargo`
  ADD PRIMARY KEY (`cargo_id`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id_cliente`);

--
-- Indices de la tabla `informe_administrativo`
--
ALTER TABLE `informe_administrativo`
  ADD PRIMARY KEY (`id_informe`),
  ADD KEY `ordenA_informe` (`ordenA_informe`),
  ADD KEY `orden_order` (`ordenP_informe`);

--
-- Indices de la tabla `orden`
--
ALTER TABLE `orden`
  ADD PRIMARY KEY (`id_ordenV`);

--
-- Indices de la tabla `orden_articulos`
--
ALTER TABLE `orden_articulos`
  ADD PRIMARY KEY (`id_articulo`),
  ADD KEY `order_orden` (`orden_id`);

--
-- Indices de la tabla `orden_pedido`
--
ALTER TABLE `orden_pedido`
  ADD PRIMARY KEY (`id_orden`),
  ADD KEY `prov_orden` (`Proveedor_orden`);

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`id_producto`);

--
-- Indices de la tabla `proveedor`
--
ALTER TABLE `proveedor`
  ADD PRIMARY KEY (`id_proveedor`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`IdUsuarios`),
  ADD UNIQUE KEY `NombreUsuario` (`username`),
  ADD KEY `cargo_user` (`cargo_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id_cliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `orden`
--
ALTER TABLE `orden`
  MODIFY `id_ordenV` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT de la tabla `orden_articulos`
--
ALTER TABLE `orden_articulos`
  MODIFY `id_articulo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `informe_administrativo`
--
ALTER TABLE `informe_administrativo`
  ADD CONSTRAINT `ordenA_informe` FOREIGN KEY (`ordenA_informe`) REFERENCES `orden_articulos` (`id_articulo`),
  ADD CONSTRAINT `orden_order` FOREIGN KEY (`ordenP_informe`) REFERENCES `orden_pedido` (`id_orden`);

--
-- Filtros para la tabla `orden_articulos`
--
ALTER TABLE `orden_articulos`
  ADD CONSTRAINT `order_orden` FOREIGN KEY (`orden_id`) REFERENCES `orden` (`id_ordenV`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `orden_pedido`
--
ALTER TABLE `orden_pedido`
  ADD CONSTRAINT `prov_orden` FOREIGN KEY (`Proveedor_orden`) REFERENCES `proveedor` (`id_proveedor`);

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `cargo_user` FOREIGN KEY (`cargo_id`) REFERENCES `cargo` (`cargo_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
