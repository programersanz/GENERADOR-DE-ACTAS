<?php
if(!isset($_REQUEST['id'])){
    header("Location:interfazVendedor.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" type="text/css" href="../css/ordenexito.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Orden Completado - PHP Carrito de Compras</title>
    <meta charset="utf-8">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@700&display=swap" rel="stylesheet">
</head>
</head>
<body>

<header>
   <nav class="menu">
    <div class="mavbar">
       <ul>
       <li>
             <a href="interfazVendedor.php">Inicio</a>
           </li>
           <li>
             <a href="RegistroCliente.php">Clientes</a>
           </li>
           <li > 
           	<a href="RegistrarProve.php">Proveedores</a>
           </li>
           <li > 
           	<a href="listaProductos.php">Todos los productos</a>
           </li>
           <li > 
           	<a href="../php/cerrarSesion.php">Cerrar</a>
           </li>
       </ul>
   </div>
   </nav>
  </header>
  
<div class="container-venta">
<div class="a">
<div class="s"> 

<ul>
  <li role="presentation"><a href="interfazVendedor.php">Inicio</a></li>
</ul>
</div>

<div class="panel-body">

    <h1>Estado de su Orden</h1>
    <p>La venta se ha registrado satisfactoriamente.</p>
           </div>
 </div>
</div>
</body>
</html>