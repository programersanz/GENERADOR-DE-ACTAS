<?php
require_once "../conf/Conexion.php";
require_once "../model/reporteAdmin.php";
?>

<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Informe administrativo</title>
   <link rel="stylesheet" type="text/css" href="../css/reporte.css">
   <script src="https://kit.fontawesome.com/6878bca7b7.js" crossorigin="anonymous"></script>
   <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@700&display=swap" rel="stylesheet">
</head>
<body>

<header>
   <nav class="menu">
    <div class="mavbar">
       <ul>
         <li>
             <a href="iinterfazadmin.php">Inicio</a>
           </li>
           <li>
             <a href="Radmin.php">Informe</a>
           </li>
           <li > 
           	<a href="RegistrarUsuario.php">Registrar usuario</a>
           </li>
           <li>
           	<a href="../php/cerrarSesion.php">Cerrar</a>
           </li>
       </ul>
   </div>
   </nav>
  </header>

    <form class="formulario" method="POST" action="../controller/reporteAdC.php">
    <h1>Registro reporte</h1>
    <div class="input-container">
     
      <input type="number" name="txtIdreporte" placeholder="Id reporte">
    </div>
        <div class="input-container">
        
      <input type="date" name="txtfechai" placeholder="Fecha informe">
    </div>
        <div class="input-container">
       
      <input type="time" name="txthora" placeholder="Hora informe">
    </div>
    <div class="input-container"> 
      <input type="text" name="txtnombre" placeholder="Nombre administrador">
    </div>

    <div class="input-container">
				
        <select name="txtordenP">
         <option>Seleccionar pedido</option>
         <?php
         $query1=  "select id_orden, fecha_orden,hora_orden,Proveedor_orden,Nombre_bodeguero,Observaciones from orden_pedido";
        $res1= mysqli_query($conexion, $query1);
         while ($row = $res1->fetch_assoc()) {
         echo '<option value= "'.$row['id_orden'].'"> '.$row['Proveedor_orden'].' '.$row['Nombre_bodeguero'].'</option>';
        }
        ?>
        </select>
                </div>
                <div class="input-container">
                <select name="txtordenA">
         <option>Seleccionar articulo</option>
         <?php
         $query1=  "select id_articulo, orden_id ,producto_id ,cantidad from orden_articulos";
        $res1= mysqli_query($conexion, $query1);
         while ($row = $res1->fetch_assoc()) {
         echo '<option value= "'.$row['id_articulo'].'"> '.$row['producto_id'].' '.$row['cantidad'].'</option>';
        }
        ?>
        </select>
                </div>
    
    <button type="submit" name="enviar" class="button">Registrar</button>
</form>  

<div class="table">
<table class="tableee">
  <thead class="head">
    <tr>
      <th>id inforem</th>
      <th>fecha informe</th>
      <th>hora informe</th>
      <th>nombre administrador</th>
      <th>orden_articulos</th>
      <th>orden_pedido</th>
      <th>Reporte</th>
      <th>Eliminar</th>
     
    </tr>
  </thead>
  <tbody class="body">
      <?php
        $obj= new Reporte();
        $datos = $obj->ListarReporte();


        foreach ($datos as $key) {
          # code...
        
      ?>
    <tr>
      <td><?php echo $key["id_informe"] ?></td>
      <td><?php echo $key["fecha_informe"] ?></td>
      <td><?php echo $key["hora_informe"] ?></td>
      <td><?php echo $key["Nombre_admin"] ?></td>
      <td><?php echo $key["ordenP_informe"] ?></td>
      <td><?php echo $key["ordenA_informe"] ?></td>
       <td><a href="reporteview.php" class="btn btn-succes">Reporte</a></td>
       <td><a href="../controller/eliminarReporteC.php?id=<?php echo $key ['id_informe']?>">Eliminar</a></td>
    </tr>
<?php } ?>
  </tbody>
</table>
</div>
</body>
</html>