<?php
require_once "../conf/Conexion.php";
require_once "../model/provedor.php";
?>

<!DOCTYPE html>
<html lang="en" >
<head>
<script src="https://kit.fontawesome.com/6878bca7b7.js" crossorigin="anonymous"></script>
	<meta charset="utf-8">
	<title>Registrar provedores</title>
	<link rel="stylesheet" type="text/css" href="../css/Proveedor.css">
   <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@700&display=swap" rel="stylesheet">
</head>
<body>

<header>
   <nav class="menu">
    <div class="mavbar">
       <ul>
            <li>
             <a href="interfazVendedor.php">Inicio</a>
           </li>
           <li>
             <a href="RegistroCliente.php">Clientes</a>
           </li>
           <li > 
           	<a href="RegistrarProve.php">Proveedores</a>
           </li>
           <li > 
           	<a href="listaProductos.php">Todos los productos</a>
           </li>
           <li > 
           	<a href="../php/cerrarSesion.php">Cerrar</a>
           </li>
       </ul>
   </div>
   </nav>
  </header>
<form class="formulario" action="../controller/proveedorC.php" method="POST">
	
		<h1>Registrar proveedor</h1>
		<div class="input-container">
		
			<input type="number" name="txtIDprovedor" placeholder="ID proveedor">
		</div>
				<div class="input-container">
				
			<input type="text" name="txtNombrepro" placeholder="Nombre proveedor">
		</div>
				<div class="input-container">
				
			<input type="text" name="txtApellidopro" placeholder="Apellido proveedor">
		</div>
				<div class="input-container">
					
			<input type="text" name="txtTelefono" placeholder="Telefono proveedor">
		</div>
		<button type="submit" name="enviar" class="button">Registrar</button>
	
</form>


<form action="../controller/buscarProveedorC.php" method="POST" class="form-search">
     <input type="text" class="buscar-texto" placeholder="Buscar producto" name="palabra">
     <button type="submit" value="buscar" class="boton">
 <i class="fas fa-search"></i>
</button>
 </form>

<div class="table">
<table class="tableee">
  <thead class="head">
    <tr>
      <th>id proveedor</th>
      <th>Nombre</th>
      <th>Apellido</th>
      <th>Teléfono</th>
      <th>Editar</th>
      <th>Eliminar</th>
    </tr>
  </thead>
  <tbody class="body">
        <?php 
             $obj= new Provedor();
             $datos= $obj->ListarProveedor();


             foreach ($datos as $key) {
            
        ?>
    <tr>
      <td><?php echo $key ["id_proveedor"]?></td>
      <td><?php echo $key ["nombre_proveedor"]?></td>
      <td><?php echo $key ["apellido_proveedor"]?></td>
      <td><?php echo $key ["telefono_proveedor"]?></td>
      <td><a href="editarProveedor.php?id=<?php echo $key ['id_proveedor']?>" class="btn btn-danger">Editar</a></td>
       <td><a href="../controller/eliminarProveedorC.php?id=<?php echo $key ['id_proveedor']?>">Eliminar</a></td>
    </tr>
    <?php } ?>
  </tbody>
</table>
</div>
</body>
</html>