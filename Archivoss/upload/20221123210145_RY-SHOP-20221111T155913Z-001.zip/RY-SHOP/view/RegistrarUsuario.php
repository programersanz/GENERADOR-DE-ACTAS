<?php 
require_once "../conf/Conexion.php";
require_once "../model/Usuario.php";
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Registrar usuario</title>
	<script src="https://kit.fontawesome.com/6878bca7b7.js" crossorigin="anonymous"></script>
	<link rel="stylesheet" type="text/css" href="../css/RegistroUsuario.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@700&display=swap" rel="stylesheet">
<body>
<header>
   <nav class="menu">
    <div class="mavbar">
       <ul>
         <li>
             <a href="iinterfazadmin.php">Inicio</a>
           </li>
           <li>
             <a href="Radmin.php">Informe</a>
           </li>
           <li > 
           	<a href="RegistrarUsuario.php">Registrar usuario</a>
           </li>
           <li>
           	<a href="../php/cerrarSesion.php">Cerrar</a>
           </li>
       </ul>
   </div>
   </nav>
  </header>  

  <form class="formulario" method="POST" action="../controller/UsuarioC.php">
    <h1>Registrar usuario</h1>
    <div class="input-container">
     
      <input type="number" name="txtIdusuario" placeholder="Id usuario">
    </div>
        <div class="input-container">
        
      <input type="text" name="txtNombreUsuario" placeholder="Nombre usuario">
    </div>
        <div class="input-container">
       
      <input type="password" name="txtcontraseña" placeholder="Contraseña">
    </div>
    <div class="input-container">
			<select name="txtcargo">
				<option>1-Admistrador</option>
				<option>2-Vendedor</option>
				<option>3-Bodeguero</option>
			</select>
		</div>
    <button type="submit" name="enviar" class="button">Registrar</button>
</form>

<div class="table">
<table class="tableee">
  <thead class="head">
    <tr>
      <th>id usuario</th>
      <th>Username</th>
      <th>Clave</th>
      <th>Cargo</th>
      <th>Editar</th>
      <th>Eliminar</th>
    </tr>
  </thead>
  <tbody class="body">
    <?php 
       $obj= new Usuario();
       $datos = $obj->ListarUsuario();

       foreach ($datos as $key) {
       
       
    ?>
    <tr>
      <td><?php echo $key ["IdUsuarios"]?></td>
      <td><?php echo $key ["username"]?></td>
      <td><?php echo $key ["clavelo"]?></td>
      <td><?php echo $key ["cargo_id"]?></td>
      <td><a href="editarUsuario.php?id=<?php echo $key ['IdUsuarios']?>" class="btn btn-danger">Editar</a></td>
       <td><a href="../controller/eliminarUsuarioC.php?id=<?php echo $key ['IdUsuarios']?>">Eliminar</a></td>
    </tr>
  <?php } ?>
  </tbody>
</table>
</div>
 </body>
</html>