
<?php
require_once "../conf/Conexion.php";
require_once "../model/reporteOrdenpedido.php";
?>

<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Orden de pedido</title>
   <link rel="stylesheet" type="text/css" href="../css/reporte.css">
   <script src="https://kit.fontawesome.com/6878bca7b7.js" crossorigin="anonymous"></script>
   <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@700&display=swap" rel="stylesheet">
</head>
<body>

<header>
    <nav class="menu">
        <div class="mavbar">
        <ul>
        <li>
              <a href="interfazBodeguero.php">inicio</a>
            </li>
            <li>
                <a  href="registroProducto.php">Registro producto</a>
            </li>
         <li>
             <a href="RordenPedido.php">Orden de pedido</a>
         </li>
         <li>
             <a href="../php/cerrarSesion.php">Cerrar sesión</a>
         </li>
        </ul>
        </div>
     
      
    </nav>
</header>

    <form class="formulario" method="POST" action="../controller/reporteOrdenPC.php">
    <h1>Registro reporte</h1>
    <div class="input-container">
      <input type="number" name="txtIdorden" placeholder="Id orden">
    </div>

        <div class="input-container">
        
      <input type="date" name="txtfechaP" placeholder="Fecha informe">
    </div>
        <div class="input-container">
       
      <input type="time" name="txthoraP" placeholder="Hora informe">
    </div>
    
    <div class="input-container">
				
    <select name="txtProveedor">
     <option>Seleccionar Proveedor</option>
     <?php
     $query1=  "select id_proveedor,nombre_proveedor,apellido_proveedor, telefono_proveedor from proveedor";
    $res1= mysqli_query($conexion, $query1);
     while ($row = $res1->fetch_assoc()) {
     echo '<option value= "'.$row['id_proveedor'].'"> '.$row['nombre_proveedor'].' '.$row['apellido_proveedor'].'</option>';
    }
    ?>
    </select>
            </div>

    <div class="input-container">
       <input type="text" name="txtnombre" placeholder="Nombre bodeguero">
     </div>

     <div class="input-container">
       <input type="text" name="txtOb" placeholder="observaciones">
     </div>
    
    <button type="submit" name="enviar" class="button">Registrar</button>
</form> 

<div class="table">
<table class="tableee">
  <thead class="head">
    <tr>
      <th>id orden</th>
      <th>fecha orden</th>
      <th>hora orden</th>
      <th>proveedor</th>
      <th>bodeguero</th>
      <th>Reporte</th>
      <th>Eliminar</th>
     
    </tr>
  </thead>
  <tbody class="body">
      <?php
        $obj= new OrdenP();
        $datos = $obj-> ListarOrdenP();


        foreach ($datos as $key) {
          # code...
        
      ?>
    <tr>
      <td><?php echo $key["id_orden"] ?></td>
      <td><?php echo $key["fecha_orden"] ?></td>
      <td><?php echo $key["hora_orden"] ?></td>
      <td><?php echo $key["Proveedor_orden"] ?></td>
      <td><?php echo $key["Nombre_bodeguero"] ?></td>
       <td><a href="ordenRview.php" class="btn btn-succes">Reporte</a></td>
       <td><a href="../controller/eliminarOrdenP.php?id=<?php echo $key ['id_orden']?>">Eliminar</a></td>
    </tr>
<?php } ?>
  </tbody>
</table>
</div>
</body>
</html>