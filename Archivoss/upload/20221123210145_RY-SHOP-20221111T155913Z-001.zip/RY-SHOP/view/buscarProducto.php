<?php 
require_once "../conf/Conexion.php";
require_once "../model/Producto.php";
?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Registrar producto</title>
  <link rel="stylesheet" type="text/css" href="../css/product1.css">
   <script src="https://kit.fontawesome.com/6878bca7b7.js" crossorigin="anonymous"></script>
</head>
<body>
<div class="container-search">
    <form action="../controller/buscarProductoC.php" method="POST" class="form-search">
        <input type="text" name="palabra" placeholder="Buscar producto" class="input-search">
    </form> 
</div>

<div class="table">
<table class="tableee">
  <thead class="head">
    <tr>
      <th>id producto</th>
      <th>Nombre producto</th>
      <th>Marca</th>
      <th>Precio</th>
      <th>Cantidad</th>
      <th>Fecha caducidad</th>
      <th>Editar</th>
      <th>Eliminar</th>
    </tr>
  </thead>
  <tbody class="body">
    <?php 
       $obj= new Producto();
       $datos = $obj->ListarProductos();

       foreach ($datos as $key) {
       
       
    ?>
    <tr>
      <td><?php echo $key ["id_producto"]?></td>
      <td><?php echo $key ["NombreProducto"]?></td>
      <td><?php echo $key ["Marca"]?></td>
      <td><?php echo $key ["precio_producto"]?></td>
      <td><?php echo $key ["cantidad"]?></td>
      <td><?php echo $key ["fecha_caducidad"]?></td>
      <td><a href="#">Editar</a></td>
       <td><a href="#">Eliminar</a></td>
    </tr>
  <?php } ?>
  </tbody>
</table>
</div>

</body>
</html>