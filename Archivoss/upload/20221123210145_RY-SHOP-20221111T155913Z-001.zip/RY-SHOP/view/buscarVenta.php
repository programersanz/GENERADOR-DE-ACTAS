<?php 
require_once "../conf/Conexion.php";
require_once "../model/venta.php";
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Administrador</title>
	<script src="https://kit.fontawesome.com/6878bca7b7.js" crossorigin="anonymous"></script>
	<link rel="stylesheet" type="text/css" href="../css/administrador.css">

<body>
<header>
   <nav class="menu">
    <div class="mavbar">
       <ul>
         <li>
             <a href="iinterfazadmin.php">Inicio</a>
           </li>
           <li>
             <a href="Radmin.php">Informe</a>
           </li>
           <li > 
           	<a href="RegistrarUsuario.php">Registrar usuario</a>
           </li>
           <li>
           	<a href="../php/cerrarSesion.php">Cerrar</a>
           </li>
       </ul>
   </div>
   </nav>
  </header>
  <form action="../controller/buscarVentaC.php" method="POST" class="form-search">
     <input type="text" class="buscar-texto" placeholder="Buscar venta" name="palabra">
     <button type="submit" value="buscar" class="boton">
     <i class="fas fa-search"></i>
 </button>
 </form>
         
  <div class="table">
<table class="tableee">
  <thead class="head">
    <tr>
      <th>id orden</th>
      <th>Precio total</th>
      <th>Fecha</th>
      <th>Hora</th>
    </tr>
  </thead>
  <tbody class="body">
    <?php 
       $obj= new Venta();
       $datos = $obj->ListarVenta();

       foreach ($datos as $key) {
       
       
    ?>
    <tr>
      <td><?php echo $key ["id_ordenV"]?></td>
      <td><?php echo $key ["precio_Total"]?></td>
      <td><?php echo $key ["fecha"]?></td>
      <td><?php echo $key ["hora"]?></td>
    </tr>
  <?php } ?>
  </tbody>
</table>
<button class="botonV">Generar Total</button>
  <button class="botonC">Eliminar</button>
</div>  
 </body>
</html>
