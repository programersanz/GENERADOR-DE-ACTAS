<?php 
require_once "../conf/Conexion.php";
require_once "../model/Producto.php";
?>

<?php

$obj= new conectar();
$id= $_GET['id'];
$sql= "SELECT * FROM producto WHERE id_producto='$id'";
$result= mysqli_query($obj->_bd, $sql);
$ver= mysqli_fetch_row($result);
?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Editar producto</title>
  <link rel="stylesheet" type="text/css" href="../css/product1.css">
   <script src="https://kit.fontawesome.com/6878bca7b7.js" crossorigin="anonymous"></script>
   <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@700&display=swap" rel="stylesheet">
</head>
<body>
<header>
    <nav class="menu">
        <div class="mavbar">
        <ul>
          <li>
              <a href="interfazBodeguero.php">inicio</a>
            </li>
            <li>
                <a href="registroProducto.php">Registro producto</a>
            </li>
         <li>
             <a href="RordenPedido.php">Orden de pedido</a>
         </li>
         <li>
             <a href="../php/cerrarSesion.php">Cerrar sesión</a>
         </li>
        </ul>
        </div>
   
      
    </nav>
</header>
  <form class="formulario" action="../controller/editarProductoC.php?id=<?php echo $_GET['id']; ?>" method="POST">
  <div class="container-form">
    <h1>Editar producto</h1>
    <div class="input-container">
     
      <input type="text" name="txtProducto" value="<?php echo $id; ?>" >
    </div>
        <div class="input-container">
         
      <input type="text" name="txtNombrepro" value="<?php echo $ver[1]?>" >
    </div>
            <div class="input-container">
       
      <input type="text" name="txtMarca" value="<?php echo $ver[2]?>">
    </div>
        <div class="input-container">
   
      <input type="number" name="txtPrecio" value="<?php echo $ver[3]?>" >
    </div>

    <div class="input-container">
      <input type="number" name="txtCant" placeholder="cantidad" value="<?php echo $ver[4]?>">
    </div>

    <div class="input-container">
     
      <input type="text" name="txtFecha" value="<?php echo $ver[5]?>" >
    </div>
    <button type="submit" name="actualizarproducto" class="buttonn">Actualizar</button>
  </div>
</form>
</body>
</html>