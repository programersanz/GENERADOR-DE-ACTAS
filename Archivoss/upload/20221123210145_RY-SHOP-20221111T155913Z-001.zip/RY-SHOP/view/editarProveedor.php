<?php
require_once "../conf/Conexion.php";
require_once "../model/provedor.php";
?>
<?php

$obj= new conectar();
$id= $_GET['id'];
$sql= "SELECT * FROM proveedor WHERE id_proveedor='$id'";
$result= mysqli_query($obj->_bd, $sql);
$ver= mysqli_fetch_row($result);
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Editar provedores</title>
	<link rel="stylesheet" type="text/css" href="../css/proveedor.css">
	<script src="https://kit.fontawesome.com/6878bca7b7.js" crossorigin="anonymous"></script>
	<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@700&display=swap" rel="stylesheet">
</head>
<body>

<header>
   <nav class="menu">
    <div class="mavbar">
       <ul>
            <li>
             <a href="interfazVendedor.php">Inicio</a>
           </li>
           <li>
             <a href="RegistroCliente.php">Clientes</a>
           </li>
           <li > 
           	<a href="RegistrarProve.php">Proveedores</a>
           </li>
           <li > 
           	<a href="listaProductos.php">Todos los productos</a>
           </li>
           <li > 
           	<a href="../php/cerrarSesion.php">Cerrar</a>
           </li>
       </ul>
   </div>
   </nav>
  </header>
<form class="formulario" action="../controller/editarProveedorC.php?id=<?php echo $_GET['id']; ?>" method="POST">
	<div class="container-form">
		<h1>Editar proveedor</h1>
		<div class="input-container">
		
			<input type="number" name="txtIDprovedor" value="<?php echo $id; ?>">
		</div>
				<div class="input-container">
				
			<input type="text" name="txtNombrepro" value="<?php echo $ver[1]?>">
		</div>
				<div class="input-container">
					
			<input type="text" name="txtApellidopro" value="<?php echo $ver[2]?>">
		</div>
				<div class="input-container">
					
			<input type="text" name="txtTelefono" value="<?php echo $ver[3]?>">
		</div>
		<button type="submit" name="actualizarProve" class="button">Actualizar</button>
	</div>
</form>
</body>
</html>