<?php 
require_once "../conf/Conexion.php";
require_once "../model/venta.php";

session_start();
if(isset($_SESSION['verificar'])) {
  if($_SESSION['username']['cargo_id'] !=1){
    header("Location: iinterfazadmin.php");
  }
}else{
  header('Location: ../index.php');
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Administrador</title>
	<script src="https://kit.fontawesome.com/6878bca7b7.js" crossorigin="anonymous"></script>
	<link rel="stylesheet" type="text/css" href="../css/administrador.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@700&display=swap" rel="stylesheet">
<body>
<header>
   <nav class="menu">
    <div class="mavbar">
       <ul>
         <li>
             <a href="iinterfazadmin.php">Inicio</a>
           </li>
           <li>
             <a href="Radmin.php">Informe</a>
           </li>
           <li > 
           	<a href="RegistrarUsuario.php">Registrar usuario</a>
           </li>
           <li>
           	<a href="../php/cerrarSesion.php">Cerrar</a>
           </li>
       </ul>
   </div>
   </nav>
  </header>
  <form action="../controller/buscarVentaC.php" method="POST" class="form-search">
     <input type="text" class="buscar-texto" placeholder="Buscar venta" name="palabra">
     <button type="submit" value="buscar" class="boton">
     <i class="fas fa-search"></i>
 </button>
 </form>
         
  <div class="table">
<table class="tableee">
  <thead class="head">
    <tr>
      <th>id orden</th>
      <th>Precio total</th>
      <th>Fecha</th>
      <th>Hora</th>
    </tr>
  </thead>
  <tbody class="body">
    <?php 
       $obj= new Venta();
       $datos = $obj->ListarVenta();

       foreach ($datos as $key) {
       
       
    ?>
    <tr>
      <td><?php echo $key ["id_ordenV"]?></td>
      <td><?php echo $key ["precio_Total"]?></td>
      <td><?php echo $key ["fecha"]?></td>
      <td><?php echo $key ["hora"]?></td>
    </tr>
  <?php } ?>
  </tbody>
</table>     
</div>  
 </body>
</html>
