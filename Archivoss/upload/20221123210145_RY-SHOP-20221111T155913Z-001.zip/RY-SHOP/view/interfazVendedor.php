<?php 
require_once "../conf/Conexion.php";
session_start();
if(isset($_SESSION['verificar'])) {
  if($_SESSION['username']['cargo_id'] !=2){
    header("Location: interfazVendedor.php");
  }
}else{
  header('Location: ../index.php');
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Interfaz vendedor</title>
	<link rel="stylesheet" type="text/css" href="../css/vendedorIn.CSS">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/6878bca7b7.js" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@700&display=swap" rel="stylesheet">
    <style>
    .container{padding: 20px;}
    .cart-link{width: 100%;text-align: right;display: block;font-size: 22px;}
    </style>
</head>
<body>
 <header>
   <nav class="menu">
    <div class="mavbar">
       <ul>
            <li>
             <a href="interfazVendedor.php">Inicio</a>
           </li>
           <li>
             <a href="RegistroCliente.php">Clientes</a>
           </li>
           <li > 
           	<a href="RegistrarProve.php">Proveedores</a>
           </li>
           <li > 
           	<a href="listaProductos.php">Todos los productos</a>
           </li>
           <li > 
           	<a href="../php/cerrarSesion.php">Cerrar</a>
           </li>
       </ul>
   </div>
   </nav>
  </header>


  <!--ventas-->
  <div class="container-venta">
<div class="a">
<div class="s"> 

<ul >
  <li role="presentation"><a href="interfazVendedor.php">Inicio</a></li>
  <li role="presentation"><a href="verCarta.php">Ver Carta</a></li>
  <li role="presentation"><a href="pagos.php">Pagos</a></li>
</ul>
</div>

<div class="panel-body">
    <h1>Mis Productos</h1>
    <a href="verCarta.php" class="cart-link" title="Ver Carta"><i class="glyphicon glyphicon-shopping-cart"></i></a>
    <div id="products" class="row list-group">
        <?php
        //get rows query
        $query = $conexion->query("SELECT * FROM producto ORDER BY id_producto DESC LIMIT 10");
        if($query->num_rows > 0){ 
            while($row = $query->fetch_assoc()){
        ?>
        <div id="pa">
            <div class="thumbnail">
                <div class="caption">
                    <h4 class="list-group-item-heading"><?php echo $row["NombreProducto"]; ?></h4>
                    <p class="list-group-item-text"><?php echo $row["Marca"]; ?></p>
                    <div class="row">
                        <div class="col-md-6">
                            <p class="lead"><?php echo '$'.$row["precio_producto"].' COP'; ?></p>
                        </div>
                        <div class="col-md-6">
                            <a class="botoneV" href="../controller/accionCarta.php?action=addToCart&id=<?php echo $row["id_producto"]; ?>">Agregar</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php } }else{ ?>
        <?php } ?>
    </div>
        </div>

 </div>
 
</div>
    
</body>
</html>