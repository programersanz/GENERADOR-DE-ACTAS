<?php 
require_once "../conf/Conexion.php";
require_once "../model/reporteOrdenpedido.php";
require_once "../model/listarProductosL.php";
?>
<?php 
ob_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1 class="text-center">Orden pedido</h1>
    <?php
        //get rows query
        $query = $conexion->query("SELECT * FROM orden_pedido ORDER BY id_orden DESC LIMIT 1");
        if($query->num_rows > 0){ 
            while($rows = $query->fetch_assoc()){
        ?>
        <h4>Hecho por:</h4>
        <p> <?php echo $rows["Nombre_bodeguero"]?></p>
        <h4>Fecha:</h4>
        <p> <?php echo $rows["fecha_orden"]?></p>

        <h4>Descripción:</h4>
        <p>En la siguiente orden de pedido se le pide al proveedor
    <?php
     $query1=  "select id_proveedor,nombre_proveedor,apellido_proveedor, telefono_proveedor from proveedor";
    $res1= mysqli_query($conexion, $query1);
     while ($row = $res1->fetch_assoc()) {
     echo '<option value= "'.$row['id_proveedor'].'"> '.$row['nombre_proveedor'].' '.$row['apellido_proveedor'].'</option>';
    }
    ?>
    llevar al local "casa de la belleza latína" ubicado en soacha dirección CLL 47 # 9-53 los siguientes productos: <b> <?php echo $rows["Observaciones"] ?></b>. Estos productos seran recibidos por el Bodeguero para su posterior registro en sistema.</p>
<br>
    <h4>Productos registrados a la fecha:</h4>
    <table class="table">
  <thead class="thead-dark">
    <tr>
      <th>id producto</th>
      <th>Nombre producto</th>
      <th>Marca</th>
      <th>Precio</th>
      <th>cantidad</th>
      <th>Fecha caducidad</th>
    </tr>
  </thead>
  <tbody class="body">
    <?php 
       $obj= new ProductoL();
       $datos = $obj->ListarProductos();

       foreach ($datos as $key) {
       
       
    ?>
    <tr>
      <td><?php echo $key ["id_producto"]?></td>
      <td><?php echo $key ["NombreProducto"]?></td>
      <td><?php echo $key ["Marca"]?></td>
      <td><?php echo $key ["precio_producto"]?></td>
      <td><?php echo $key ["cantidad"]?></td>
      <td><?php echo $key ["fecha_caducidad"]?></td>
    </tr>

  <?php } ?>
  </tbody>
</table>
<br>
<br>
<br>
<br>
<br>




<div>
    <h6>Firma Administrador:</h6>
    <P>_______________________<P>
       </div>

    

    <?php } }else{ ?>
        <?php } ?>
</body>
</html>

<?php 
$html=ob_get_clean();
require_once '../library/dompdf/autoload.inc.php';
use Dompdf\Dompdf;
$dompdf = new Dompdf();

$options = $dompdf->getOptions();
$options->set(array('isRemoteEnabled'=>true));
$dompdf->setOptions($options);

$dompdf->loadHtml($html);
$dompdf->setPaper('letter');
//$dompdf->setPaper('A4', 'landscape');

$dompdf->render();
$dompdf->stream("prueba", array ("Attachment"=>false));
?>