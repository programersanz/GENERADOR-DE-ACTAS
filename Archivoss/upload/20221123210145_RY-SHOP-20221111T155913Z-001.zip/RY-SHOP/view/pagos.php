<?php
// include database configuration file
include '../conf/Conexion.php';

// initializ shopping cart class
include '../model/modelCarta.php';
$cart = new carta;

// redirect to home if cart is empty
if($cart->total_itemss() <= 0){
    header("Location: interfazVendedor.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Pagos - PHP Carrito de compras Tutorial</title>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="../css/pagos.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@700&display=swap" rel="stylesheet">
</head>
<body>

<header>
   <nav class="menu">
    <div class="mavbar">
       <ul>
       <li>
             <a href="interfazVendedor.php">Inicio</a>
           </li>
           <li>
             <a href="RegistroCliente.php">Clientes</a>
           </li>
           <li > 
           	<a href="RegistrarProve.php">Proveedores</a>
           </li>
           <li > 
           	<a href="listaProductos.php">Todos los productos</a>
           </li>
           <li > 
           	<a href="../php/cerrarSesion.php">Cerrar</a>
           </li>
       </ul>
   </div>
   </nav>
  </header>

<div class="container-venta">
<div class="a">
<div class="s"> 

<ul>
  <li role="presentation"><a href="interfazVendedor.php">Inicio</a></li>
  <li role="presentation"><a href="verCarta.php">Ver Carta</a></li>
  <li role="presentation"><a href="pagos.php">Pagos</a></li>
</ul>
</div>

<div class="panel-body">
    <h1>Vista previa de la Orden</h1>
    <table class="table">
    <thead>
        <tr>
            <th>Producto</th>
            <th>Precio</th>
            <th>Cantidad</th>
            <th>Sub total</th>
        </tr>
    </thead>
    <tbody>
        <?php
        if($cart->total_itemss() > 0){
            //get cart items from session
            $cartItems = $cart->contents();
            foreach($cartItems as $item){
        ?>
        <tr>
            <td><?php echo $item["name"]; ?></td>
            <td><?php echo '$'.$item["price"].' COP'; ?></td>
            <td><?php echo $item["qty"]; ?></td>
            <td><?php echo '$'.$item["subtotal"].' COP'; ?></td>
        </tr>
        <?php } }else{ ?>
        <tr><td colspan="4"><p>No hay articulos en tu carta......</p></td>
        <?php } ?>
    </tbody>
    <tfoot>
        <tr>
            <td colspan="3"></td>
            <?php if($cart->total_itemss() > 0){ ?>
            <td class="text-center"><strong>Total <?php echo '$'.$cart->total().' COP'; ?></strong></td>
            <?php } ?>
        </tr>
    </tfoot>
    </table>
    <div class="btn">
        <a href="interfazVendedor.php" class="boton"><i class="glyphicon glyphicon-menu-left"></i> Continuar comprando</a>
        <a href="../controller/accionCarta.php?action=placeOrder" class="boton">Realizar pedido <i class="glyphicon glyphicon-menu-right"></i></a>
    </div>
        </div>
 </div>
</div>
</body>
</html>