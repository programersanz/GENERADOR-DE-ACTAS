<?php 
require_once "../conf/Conexion.php";
require_once "../model/Producto.php";
?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Registrar producto</title>
  <link rel="stylesheet" type="text/css" href="../css/product1.css">
   <script src="https://kit.fontawesome.com/6878bca7b7.js" crossorigin="anonymous"></script>
   <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
   <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@700&display=swap" rel="stylesheet">
</head>
<body>

<header>
    <nav class="menu">
        <div class="mavbar">
        <ul>
          <li>
              <a href="interfazBodeguero.php">inicio</a>
            </li>
            <li>
                <a href="registroProducto.php">Registro producto</a>
            </li>
         <li>
             <a href="RordenPedido.php">Orden de pedido</a>
         </li>
         <li>
             <a href="../php/cerrarSesion.php">Cerrar sesión</a>
         </li>
        </ul>
        </div>
   
      
    </nav>
</header>
  <form class="formulario" action="../controller/productoC.php" method="POST">
  <div class="container-form">
    <h1>Registrar producto</h1>
    <div class="input-container">
    
      <input type="number" name="txtProducto" placeholder="Id producto">
    </div>
        <div class="input-container">
     
      <input type="text" name="txtNombrepro" placeholder="Nombre producto">
    </div>
            <div class="input-container">
      
      <input type="text" name="txtMarca" placeholder="Marca producto">
    </div>
    <div class="input-container">
  
      <input type="number" name="txtPrecio" placeholder="Precio producto">
    </div>
    <div class="input-container">
      <input type="number" name="txtCant" placeholder="cantidad">
    </div>
    <div class="input-container">
     
      <input type="date" name="txtFecha" placeholder="Fecha caducidad">
    </div>
    <button type="submit" name="enviar" class="buttonn">Registrar</button>
  </div>
</form>

<form action="../controller/buscarProductoC.php" method="POST" class="form-search">
     <input type="text" class="buscar-texto" placeholder="Buscar producto" name="palabra">
     <button type="submit" value="buscar" class="boton">
 <i class="fas fa-search"></i>
</button>
 </form>

<div class="table">
<table class="tableee">
  <thead class="head">
    <tr>
      <th>id producto</th>
      <th>Nombre producto</th>
      <th>Marca</th>
      <th>Precio</th>
      <th>cantidad</th>
      <th>Fecha caducidad</th>
      <th>Editar</th>
      <th>Eliminar</th>
    </tr>
  </thead>
  <tbody class="body">
    <?php 
       $obj= new Producto();
       $datos = $obj->ListarProductos();

       foreach ($datos as $key) {
       
       
    ?>
    <tr>
      <td><?php echo $key ["id_producto"]?></td>
      <td><?php echo $key ["NombreProducto"]?></td>
      <td><?php echo $key ["Marca"]?></td>
      <td><?php echo $key ["precio_producto"]?></td>
      <td><?php echo $key ["cantidad"]?></td>
      <td><?php echo $key ["fecha_caducidad"]?></td>
      <td><a href="editarProducto.php?id=<?php echo $key ['id_producto']?>" class="btn btn-danger">Editar</a></td>
       <td><a href="../controller/eliminarProductoC.php?id=<?php echo $key ['id_producto']?>">Eliminar</a></td>
    </tr>
  <?php } ?>
  </tbody>
</table>
</div>

</body>
</html>
