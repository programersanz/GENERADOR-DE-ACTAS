<?php 
require_once "../conf/Conexion.php";
require_once "../model/venta.php";
require_once "../model/reporteAdmin.php";
require_once "../model/listarProductosL.php";
?>
<?php 
ob_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1 class="text-center">Informe administrativo</h1>
    <?php
        //get rows query
        $query = $conexion->query("SELECT * FROM informe_administrativo ORDER BY id_informe DESC LIMIT 1");
        if($query->num_rows > 0){ 
            while($row = $query->fetch_assoc()){
        ?>
             <h6>Fecha: <p><?php echo $row["fecha_informe"] ?></p></h6>
             <h6>Hecho por: <p><?php echo $row["Nombre_admin"] ?></p></h6>
       
             <h6 class="text-center">Descripción</h6>
             <p>El siguiente informe tiene información relacionada con las ventas hechas hasta el presente día y la existencia de productos hasta la fecha</p>
 

    <?php } }else{ ?>
        <?php } ?>
    <h4>ventas:</h4>
<table class="table">
  <thead class="thead-dark">
    <tr>
      <th>id orden</th>
      <th>Precio total</th>
      <th>Fecha</th>
      <th>Hora</th>
    </tr>
  </thead>
  <tbody>
    <?php 
       $obj= new Venta();
       $datos = $obj->ListarVenta();

       foreach ($datos as $key) {
       
       
    ?>
    <tr>
      <td><?php echo $key ["id_ordenV"]?></td>
      <td><?php echo $key ["precio_Total"]?></td>
      <td><?php echo $key ["fecha"]?></td>
      <td><?php echo $key ["hora"]?></td>
    </tr>
  <?php } ?>
  </tbody>
</table> 
<br>
<br>
<br>
<h4>Productos</h4>
<table class="table">
  <thead class="thead-dark">
    <tr>
      <th>id producto</th>
      <th>Nombre producto</th>
      <th>Marca</th>
      <th>Precio</th>
      <th>cantidad</th>
      <th>Fecha caducidad</th>
    </tr>
  </thead>
  <tbody class="body">
    <?php 
       $obj= new ProductoL();
       $datos = $obj->ListarProductos();

       foreach ($datos as $key) {
       
       
    ?>
    <tr>
      <td><?php echo $key ["id_producto"]?></td>
      <td><?php echo $key ["NombreProducto"]?></td>
      <td><?php echo $key ["Marca"]?></td>
      <td><?php echo $key ["precio_producto"]?></td>
      <td><?php echo $key ["cantidad"]?></td>
      <td><?php echo $key ["fecha_caducidad"]?></td>
    </tr>
  <?php } ?>
  </tbody>
</table>
</body>
</html>

<?php 
$html=ob_get_clean();
require_once '../library/dompdf/autoload.inc.php';
use Dompdf\Dompdf;
$dompdf = new Dompdf();

$options = $dompdf->getOptions();
$options->set(array('isRemoteEnabled'=>true));
$dompdf->setOptions($options);

$dompdf->loadHtml($html);
$dompdf->setPaper('letter');
//$dompdf->setPaper('A4', 'landscape');

$dompdf->render();
$dompdf->stream("prueba", array ("Attachment"=>false));
?>