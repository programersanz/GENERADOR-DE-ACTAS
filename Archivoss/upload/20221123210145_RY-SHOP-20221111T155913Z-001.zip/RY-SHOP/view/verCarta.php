<?php
// initializ shopping cart class
include '../model/modelCarta.php';
$cart = new carta;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>View Cart - PHP Shopping Cart Tutorial</title>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="../css/carta.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@700&display=swap" rel="stylesheet">
    <script>
    function updateCartItem(obj,id){
        $.get("cartAction.php", {action:"updateCartItem", id:id, qty:obj.value}, function(data){
            if(data == 'ok'){
                location.reload();
            }else{
                alert('Cart update failed, please try again.');
            }
        });
    }
    </script>
</head>
</head>
<body>

<header>
   <nav class="menu">
    <div class="mavbar">
       <ul>
       <li>
             <a href="interfazVendedor.php">Inicio</a>
           </li>
           <li>
             <a href="RegistroCliente.php">Clientes</a>
           </li>
           <li > 
           	<a href="RegistrarProve.php">Proveedores</a>
           </li>
           <li > 
           	<a href="listaProductos.php">Todos los productos</a>
           </li>
           <li > 
           	<a href="../php/cerrarSesion.php">Cerrar</a>
           </li>
       </ul>
   </div>
   </nav>
  </header>
  
<div class="container-venta">
<div class="a">
<div class="s"> 

<ul>
  <li role="presentation"><a href="interfazVendedor.php">Inicio</a></li>
  <li role="presentation"><a href="verCarta.php">Ver Carta</a></li>
  <li role="presentation"><a href="pagos.php">Pagos</a></li>
</ul>
</div>

<div class="panel-body">


    <h1>Carrito de compras</h1>
    <table class="table">
    <thead>
        <tr>
            <th>Producto</th>
            <th>Precio</th>
            <th>Cantidad</th>
            <th>Sub total</th>
            <th>&nbsp;</th>
        </tr>
    </thead>
    <tbody>
        <?php
        if($cart->total_itemss() > 0){
            //get cart items from session
            $cartItems = $cart->contents();
            foreach($cartItems as $item){
        ?>
        <tr>
            <td><?php echo $item["id"]; ?></td>
            <td><?php echo '$'.$item["price"].' COP'; ?></td>
            <td><input type="number" class="form-control text-center" value="<?php echo $item["qty"]; ?>" onchange="updateCartItem(this,'<?php echo $item["rowid"]; ?>')"></td>
            <td><?php echo '$'.$item["subtotal"].' COP'; ?></td>
            <td>
                <a href="../controller/accionCarta.php?action=removeCartItem&id=<?php echo $item["rowid"]; ?>" class="boton" onclick="return confirm('Confirma eliminar?')">Borrar<i class="glyphicon glyphicon-trash"></i></a>
            </td>
        </tr>
        <?php } }else{ ?>
        <tr><td colspan="5"><p>Tu carta esta vacia.....</p></td>
        <?php } ?>
    </tbody>
    <tfoot class="tfoot">
        <tr>
            <td><a href="interfazVendedor.php" class="boton"><i class="glyphicon glyphicon-menu-left"></i> Continue Comprando</a></td>
            <td colspan="2"></td>
            <?php if($cart->total_itemss() > 0){ ?>
            <td class="text-center"><strong>Total <?php echo '$'.$cart->total().' COP'; ?></strong></td>
            <td><a href="pagos.php" class="boton">Pagos <i class="glyphicon glyphicon-menu-right"></i></a></td>
            <?php } ?>
        </tr>
    </tfoot>
    </table>
    
    </div>
 </div>
 
</div>
</body>
</html>